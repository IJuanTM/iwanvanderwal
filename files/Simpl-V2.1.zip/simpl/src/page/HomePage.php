<?php

class HomePage
{
//PHP code for homepage
}
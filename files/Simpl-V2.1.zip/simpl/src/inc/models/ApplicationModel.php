<?php

class ApplicationModel
{

}
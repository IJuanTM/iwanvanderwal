<?php

class PageModel
{
    public array $urlArr;

    public function set_urlArr(array $urlArr)
    {
        $this->urlArr = $urlArr;
    }
}
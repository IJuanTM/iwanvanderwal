<?php

class ValidatePage
{

}
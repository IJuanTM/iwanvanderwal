<?php

class ContactPage
{
    public function __construct()
    {
        // Check if all inputs are entered when button is pressed
        if (isset($_POST['submit-contact'])) {
            if (!empty($_POST['name-contact'])) {
                if (!empty($_POST['email-contact'])) {
                    if (!empty($_POST['subject-contact'])) {
                        if (!empty($_POST['message-contact'])) {
                            MailController::siteContact_mail($_POST['name-contact'], $_POST['email-contact'], $_POST['subject-contact'], $_POST['message-contact']);
                            MailController::userContact_mail($_POST['email-contact']);
                        } else FormController::form_message('Please enter a message!', 'warning', null, 'contact');
                    } else FormController::form_message('Please enter a subject!', 'warning', null, 'contact');
                } else FormController::form_message('Please enter your own mail!', 'warning', null, 'contact');
            } else FormController::form_message('Please enter your name!', 'warning', null, 'contact');
        }
    }
}
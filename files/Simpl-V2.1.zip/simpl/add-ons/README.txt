By:         Iwan van der Wal (IJuanTM)
Date:       14 - Oct - 2020
Project:    Simpl (v2.1)

-=- Information about add-ons -=-
In the add-ons folder you'll find sub-folders containing extra files you can add to your Simpl project. In these
folder there are files that add extra functions, help understanding existing functions or just somethings I have created
before and might come in handy.

- inc
Here you'll find, just like in the src/inc folder, 3 subfolders. Containing controllers and models, as well as a lib
folder containing an database file. In the controller folder you will find extra controllers to add to your project, like
a UserController for logins and registration, a MailController for sending automated mails, a FormContoller for easy form
making, and there is more to come! In the lib/database file you will find code to make connections to a mysql based
database. In the models folder are the needed model files that you'll need when you add it's contoller to your project.

- js
Here you'll find a JavaScript file with some of my own code I wrote which you can use!

- page
Some example page files like, a contact page, login and registration pages and a page to validate your account.

- style
Here are some SCSS files with own designs I made for things like forms structure, and more to come!

- view
Here you'll find the corresponding files to the Page files, like the login and registration pages. As well as some
example automated mails, and a index/js file which contains the code to load the js file in the js folder.

That's all in short! If you have more questions, please ask them over on GitHub!
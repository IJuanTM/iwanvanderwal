<?php
/**
 * If you use controllers/MailController.php
 * add this line to your config.php underneath
 * the other folder constants
 */

// Set needed folders for page loading
define('MAILS', PARTS . 'mails/');

/**
 * If you use Google reCaptcha on your site
 * add this constant for your sitekey
 */

// Set the sitekey for reCaptcha
define('SITEKEY', '');